//INITIALISE VARIABLES

//Black and White Librarian Object
let bwLibrarian = {
  sprite: null,
  xPos: 150,
  yPos: 150,
  hitPionts: 10,
  textPaddingX: 50,
  textPaddingY: -25,

  display: function() {
    image(this.sprite, this.poX, this.posY);

    textSize(20);
    text(this.hitPionts, this.poX + this.textPaddingX, this.posY + this.textPaddingY)
  }
}


function preload(){
  bwLibrarian.sprite = loadImage("librarian-bw.png");
}

function setup() {
 // put setup code here
  createCanvas (400,400);
}

function draw() {
  // put drawing code here
  background(250);
  bwLibrarian.display
}
